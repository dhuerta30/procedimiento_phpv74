import { cargarDatos, cargarDatosLocalStorage } from "../js/gastos.js";
import { cargarMotivos } from "../js/motivos.js";
import { listar_datos_perfil } from "../js/perfil.js";
import { cargarInventarioCompras, cargar_lugar_de_compra } from "../js/inventario_compra.js";

$$(document).on("click", ".salir_page", function(){
    window.location.href = "index.html";
});

$$(document).on('click', '.home_page', function () {
    viewHome.router.navigate('/home/');
});

$$(document).on('click', '.gastos_page', function () {
    viewHome.router.navigate('/gastos/');
    setTimeout(function(){
        cargarDatos();
    }, 1000);
});

$$(document).on('click', '.inventario_page', function () {
    viewHome.router.navigate('/inventario/');
    setTimeout(function(){
        cargarInventarioCompras();
    }, 1000);
});

$$(document).on('click', '.motivo_page', function () {
    viewHome.router.navigate('/motivo/');
    setTimeout(function(){                                                                                                                                                                      
        cargarMotivos();
    }, 1000);
});

$$(document).on('click', '.lugar_de_compra_page', function () {
    viewHome.router.navigate('/lugar_de_compra/');
    setTimeout(function(){
        cargar_lugar_de_compra();
    }, 1000);
});

$$(document).on('click', '.perfil_page', function () {
    viewHome.router.navigate('/perfil/');
    setTimeout(function(){
        listar_datos_perfil();
    }, 1000);
});

$$(document).on("page:beforein", function (e){
    cargarPanel();
    cargarMenuInferior();
});

function cargarPanel(){
    app.preloader.show();
    fetch("pages/panel.html", {
        method: "GET",
        headers: { "Content-Type": "application/html" }
    })
    .then(response => response.text())
    .then(result => {
        app.preloader.hide();
        $('.menu_lateral').html(result);
    });
}

export { cargarPanel };

function cargarMenuInferior(){
    app.preloader.show();
    fetch("pages/menu_inferior.html", {
        method: "GET",
        headers: { "Content-Type": "application/html" }
    })
    .then(response => response.text())
    .then(result => {
        app.preloader.hide();
        $('.menu_inferior').html(result);
    });
}

export { cargarMenuInferior };

// Event listener para el botón de inicio de sesión
$$(document).on('click', '.acceder', function (e) {
    e.preventDefault(); // Evitar comportamiento predeterminado del formulario

    // Obtener valores de usuario y contraseña
    let usuario = $$('.username').val();
    let clave = $$('.password').val();

    if (usuario === "" && clave === "") {
        app.dialog.alert("El usuario y contraseña están vacíos");
    } else {
        var isChecked = $$('.recordar_usuario').prop('checked');
        if (isChecked) {
            let datauser = {
                usuario: usuario,
                clave: clave
            };
            localStorage.setItem('loginData', JSON.stringify(datauser));
        }

        app.preloader.show();
        // Realizar solicitud POST al servidor para autenticar al usuario
        fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                accion: "obtenerToken",
                usuario: usuario,
                clave: clave
            })
        })
        .then(response => response.json())
        .then(result => {
            // Verificar si la autenticación fue exitosa
            if (result.message) {
                // Guardar información de usuario en el almacenamiento local
                localStorage.setItem('tokenData', JSON.stringify(result.token));
                sessionStorage.setItem('session', "sesionIniciada");
                localStorage.setItem('UserData', JSON.stringify(result.data));
                
                app.dialog.alert(result.message, function(){
                    viewHome.router.navigate('/home/');
                    /*setTimeout(function() {
                        cargarDatos();
                    }, 1000);*/
                });
                app.preloader.hide();
            } else {
                app.preloader.hide();
                // Mostrar mensaje de error
                app.dialog.alert(result.error);
            }
        })
        .catch(error => {
            if (error instanceof TypeError && error.message === 'Failed to fetch') {
                // Obtener credenciales almacenadas localmente
                var loginDataString = localStorage.getItem('loginData');
                if (loginDataString) {
                    var loginData = JSON.parse(loginDataString);
                    
                    // Verificar si las credenciales coinciden con las ingresadas por el usuario
                    if (loginData.usuario === usuario && loginData.clave === clave) {
                        app.dialog.alert('Inicio de sesión exitoso. No hay conexión a Internet.', function(){
                            app.preloader.hide();
                            viewHome.router.navigate('/home/');
                            setTimeout(function() {
                                cargarDatosLocalStorage();
                            }, 1000);
                        });
                        return; // Salir del manejador de error después de mostrar el mensaje
                    }
                }
                app.dialog.alert("No se encontró el usuario o la contraseña es incorrecta");
            }
        });
    }
});


function sesionIniciada(){
    var session = sessionStorage.getItem('session');
    if (session) {
        sessionStorage.removeItem('session');
        // Verificar si ya estamos en "index.html"
        if (window.location.href.indexOf("index.html") === -1) {
            // Solo redirigir si no estamos en "index.html"
            window.location.href = "index.html";
        }
    }
}

export { sesionIniciada };

sesionIniciada();

$$(document).on("change", ".recordar_usuario", function(){
    // Obtener el estado actual del checkbox
    var isChecked = $$(this).prop('checked');
    
    // Mostrar un mensaje de alerta con el estado del checkbox
    if(isChecked){
        if (localStorage.getItem('loginData')) {
            var loginDataString = localStorage.getItem('loginData');
            var loginData = JSON.parse(loginDataString);

            $$(".username").val(loginData.usuario);
            $$(".password").val(loginData.clave);
        }
    } else {
        $$(".username").val("");
        $$(".password").val("");
    }
});


$$(document).on("keyup", ".buscar_tareas", function(){
    $$(".sin_data").hide();
});