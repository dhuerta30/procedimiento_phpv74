import { obtenerToken } from "../js/token.js";

$$(document).on("click", ".enviar_notificacion", function(){
    let titulo = $$(".titulo_notify").val();
    let foto = $("#foto_notify").attr("src");
    let mensaje = $$(".mensaje_notify").val();

    var token = obtenerToken();

    if(titulo == ""){
        app.dialog.alert('El Titulo está vacio');
    } else if(mensaje == ""){
        app.dialog.alert('El Mensaje está vacio');
    } else {
        fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                accion: "enviar_notificaciones",
                titulo: titulo,
                foto: foto,
                mensaje: mensaje,
                token: token
            })
        })
        .then(response => response.json())
        .then(result => {
            let obt = result;

            if(obt){
                app.preloader.hide();
                $$('.titulo_notify').val("");
                $$('.mensaje_notify').val("");

                var json = JSON.parse(obt.data);

                var titulo = json.headings.en;
                var mensaje = json.contents.en;
                var foto = json.big_picture;

                var notificationWithButton = app.notification.create({
                    icon: '<img width="30" src="'+ foto +'">',
                    title: titulo,
                    subtitle: mensaje,
                    text: 'Click en la (x) Para cerrar',
                    closeButton: true,
                });
                notificationWithButton.open();
            }
        })
        .catch(error => {
            app.preloader.hide();
            if (error instanceof TypeError && error.message === 'Failed to fetch') {
                app.dialog.alert("Para Enviar una Notificación Revise su conexión a internet");
            }
        });
    }
});