import { obtenerToken } from "../js/token.js";
import { obtenerUsuario } from "../js/usuario.js";

let dataTable_motivo; // Variable para almacenar la referencia al DataTable

function cargarMotivos() {
    var user = obtenerUsuario();
    let sesion_user = user[0].usuario;

    var token = obtenerToken();

    app.preloader.show();

    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "listar_motivos_de_compra",
            token: token,
            usuario: sesion_user
        })
    })
    .then(response => response.json())
    .then(result => {
        let Tabla = result.data;

        // Destruir el DataTable existente si ya existe
        if (dataTable_motivo) {
            dataTable_motivo.destroy();
        }

        // Llenar la tabla con los datos obtenidos y almacenar la referencia al DataTable
        dataTable_motivo = $('.table_motivo').DataTable({
            data: Tabla,
            pagingType: 'simple',
            searching: true,
            bLengthChange: false,
            scrollX: true,
            processing: true,
            serverside: true,
            pageLength: 5,
            language: {
                "decimal": "",
                "emptyTable": "No hay información",
                "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
                "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
                "infoFiltered": "(Filtrado de _MAX_ total entradas)",
                "infoPostFix": "",
                "thousands": ",",
                "lengthMenu": "Mostrar _MENU_ Entradas",
                "loadingRecords": "Cargando...",
                "processing": "Procesando...",
                "search": "Buscar:",
                "zeroRecords": "Sin resultados encontrados",
                "paginate": {
                    "first": "Primero",
                    "last": "Ultimo",
                    "next": "<div class='f7-icons'>arrow_right_circle_fill</div>",
                    "previous": "<div class='f7-icons'>arrow_left_circle_fill</div>"
                }
            },
            columnDefs: [
                { targets: [0], className: 'numeric-cell' },
                { targets: [1], className: 'numeric-cell' }
            ],
            columns: [
                { data: 'id_motivo_de_compra' },
                { data: 'nombre' },
                {
                    render: function(data, type, row, meta){
                        return ` <p class="grid grid-cols-2 grid-gap">
                                    <button class="button button-small button-fill editar_motivo" data-id="${row.id_motivo_de_compra}"><span class="f7-icons">pencil</span></button>
                                    <button class="button button-small button-fill color-red eliminar_motivo" data-id="${row.id_motivo_de_compra}"><span class="f7-icons">trash</span></button>
                                </p>`;
                    }
                }
            ]
        });
        app.preloader.hide();
    })
    .catch(error => {
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            app.preloader.hide();
            setTimeout(function(){
                cargarMotivosLocalStorage();
            }, 1000);
        }
    });
}

export { cargarMotivos };

let dataTable_motivoStorage; // Variable para almacenar la referencia al DataTable

function cargarMotivosLocalStorage(){
    var datosLocalStorage = localStorage.getItem("data_motivos");
    var datos = JSON.parse(datosLocalStorage);

    var datosParaDataTable = {
        data: datos,
    };

    let Tabla = datosParaDataTable.data;

        // Destruir el DataTable existente si ya existe
        if (dataTable_motivoStorage) {
            dataTable_motivoStorage.destroy();
        }

        dataTable_motivoStorage = $('.table_motivo').DataTable({
        data: Tabla,
        pagingType: 'simple',
        searching: true,
        bLengthChange: false,
        scrollX: true,
        pageLength: 5,
        processing: true,
        serverside: true,
        language: {
            "decimal": "",
            "emptyTable": "No hay información",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
            "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
            "infoFiltered": "(Filtrado de _MAX_ total entradas)",
            "infoPostFix": "",
            "thousands": ",",
            "lengthMenu": "Mostrar _MENU_ Entradas",
            "loadingRecords": "Cargando...",
            "processing": "Procesando...",
            "search": "Buscar:",
            "zeroRecords": "Sin resultados encontrados",
            "paginate": {
                "first": "Primero",
                "last": "Ultimo",
                "next": "<div class='f7-icons'>arrow_right_circle_fill</div>",
                "previous": "<div class='f7-icons'>arrow_left_circle_fill</div>"
            }
        },
        columnDefs: [
            { targets: [0], className: 'numeric-cell' },
            { targets: [1], className: 'numeric-cell' }
        ],
        columns: [
            { data: 'id_motivo' },
            { data: 'nombre' },
            {
                render: function(data, type, row, meta){
                    return ` <p class="grid grid-cols-2 grid-gap">
                                <button class="button button-small button-fill editar_motivo" data-id="${row.id_motivo}"><span class="f7-icons">pencil</span></button>
                                <button class="button button-small button-fill color-red eliminar_motivo" data-id="${row.id_motivo}"><span class="f7-icons">trash</span></button>
                            </p>`;
                }
            }
        ]
    });
}

export { cargarMotivosLocalStorage };

$$(document).on("click", ".guardar_motivo", function(e){
    e.preventDefault();

    let nombre = $$(".nombre_motivo").val();
    var token = obtenerToken();

    if(nombre == ""){
        app.dialog.alert('El Nombre está vacio');
    } else {
        fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                accion: "insertar_motivo",
                nombre: nombre,
                token: token
            })
        })
        .then(response => response.json())
        .then(result => {
            // Verificar si la autenticación fue exitosa
            if (result.resultado) {                  
                $$('.nombre_motivo').val("");
                app.dialog.alert(result.resultado, function(){
                    $$(".popup-close").click();
                    cargarMotivos();

                    let motivos = JSON.parse(localStorage.getItem('data_motivos')) || [];
                    motivos.push({
                        id_motivo: result.id_motivo,
                        nombre: nombre,
                    });
                    localStorage.setItem('data_motivos', JSON.stringify(motivos));
                });
            } else {
                // Mostrar mensaje de error
                app.dialog.alert(result.error);
            }
        })
        .catch(error => {
            app.preloader.hide();
            if (error instanceof TypeError && error.message === 'Failed to fetch') {
                app.dialog.alert("Para Agregar este Motivo de Compra Revise su conexión a internet");
            }
        });
    }
});

function cargar_motivos(id = ''){
    var user = obtenerUsuario();
    let sesion_user = user[0].usuario;

    var token = obtenerToken();

    app.preloader.show();
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "listar_motivos_de_compra",
            token: token,
            usuario: sesion_user
        })
    })
    .then(response => response.json())
    .then(result => {
         let obt = result.data;

         app.preloader.hide();
         $('.motivo_gasto, .motivo_edit').empty();
         $('.motivo_gasto, .motivo_edit').html(`<option value="0">Seleccione Motivo de Compra</option>`);
         $.each(obt, function(index, obj){
            $('.motivo_gasto, .motivo_edit').append(`
                <option value="${obj.nombre}">${obj.nombre}</option>
            `);
         });

         if (id !== '') {
            $('.motivo_edit').val(id);
        } else {
            $('.motivo_edit').val('0'); // Asegúrate de que se seleccione "Seleccionar" si id está vacío
        }

    })
    .catch(error => {
        app.preloader.hide();
        if (error instanceof TypeError && error.message === 'Failed to fetch') {

            var datosLocalStorage = localStorage.getItem("data_motivos");
            var datos = JSON.parse(datosLocalStorage);

            var datosParaDataTable = {
                data: datos,
            };

            let obt = datosParaDataTable.data;

            $('.motivo_gasto, .motivo_edit').empty();
            $('.motivo_gasto, .motivo_edit').html(`<option value="0">Seleccione Motivo de Compra</option>`);
            $.each(obt, function(index, obj){
                $('.motivo_gasto, .motivo_edit').append(`
                    <option value="${obj.nombre}">${obj.nombre}</option>
                `);
            });
        }
    });
}
export { cargar_motivos };

function eliminarMotivoLocalStorage(id) {
    // Obtener la lista de gastos del almacenamiento local
    let motivos = JSON.parse(localStorage.getItem('data_motivos')) || [];

    // Filtrar la lista para eliminar el gasto con el ID especificado
    motivos = motivos.filter(motivo => motivo.id_motivo !== id);

    // Guardar la lista actualizada en el almacenamiento local
    localStorage.setItem('data_motivos', JSON.stringify(motivos));
}

export { eliminarMotivoLocalStorage };

$$(document).on("click", ".eliminar_motivo", function(){
    let id = $$(this).data("id");
    let token = obtenerToken();

    app.dialog.confirm('¿Estás seguro de eliminar este motivo de compra?', function(){
        // Muestra el spinner de carga antes de realizar la solicitud
        app.preloader.show();

        fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                accion: "eliminar_motivo",
                id: id,
                token: token
            })
        })
        .then(response => response.json())
        .then(result => {
            let obt = result.resultado;

            if(obt){
                app.preloader.hide();
                app.dialog.alert(obt, function(){
                    cargarMotivos();
                    eliminarMotivoLocalStorage(id);
                });
            }
        })
        .catch(error => {
            app.preloader.hide();
            if (error instanceof TypeError && error.message === 'Failed to fetch') {
                app.dialog.alert("Para Eliminar este Motivo de Compra Revise su conexión a internet");
            }
        });
    });
});

$$(document).on("click", ".editar_motivo", function(){
    let id = $$(this).data("id");
    let token = obtenerToken();

    app.preloader.show();
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "listar_motivos_por_id",
            id: id,
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
        let obt = result.resultado;

        app.popup.open('.editar_poup_motivo');

        $$(".nombre_edit").val(obt[0].nombre);
        $$(".id_motivo").val(obt[0].id_motivo_de_compra);
        app.preloader.hide();
    })
    .catch(error => {
        app.preloader.hide();
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            app.dialog.alert("Para Mostrar los Datos Revise su conexión a internet");
        }
    });
});

$$(document).on("click", ".actualizar_motivo", function(){
    let id = $$(".id_motivo").val();
    let nombre = $$(".nombre_edit").val();
    let token = obtenerToken();

    app.preloader.show();
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "actualizar_motivo",
            id: id,
            nombre: nombre,
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
        let obt = result.resultado;

        if(obt){
            app.preloader.hide();
            app.dialog.alert(result.resultado, function(){
                $$(".popup-close").click();
                cargarMotivos();
            });
        }
    })
    .catch(error => {
        app.preloader.hide();
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            app.dialog.alert("Para Actualizar los Datos Revise su conexión a internet");
        }
    });
});