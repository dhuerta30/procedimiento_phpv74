$$(document).on("click", ".registrar_usuario", function(){
    let usuario = $$(".usuario_register").val();
    let nombre = $$(".nombre_register").val();
    let correo = $$(".correo_register").val();
    let foto = $$("#foto").attr("src");
    let clave = $$(".clave_register").val();

    if(usuario == ""){
        app.dialog.alert('El usuario está vacio');
    } else if(nombre == ""){
        app.dialog.alert('El Nombre está vacio');
    } else if(correo == ""){
        app.dialog.alert('El Correo está vacio');
    } else if(!(/^data:image\/(png|jpeg|jpg|gif);base64,/.test(foto))){
        app.dialog.alert('La Foto está vacia');
    } else if(clave == ""){
        app.dialog.alert('La contraseña está vacia');
    } else {
        fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                accion: "insertar_usuario",
                usuario: usuario,
                clave: clave,
                nombre: nombre,
                correo: correo,
                foto: foto
            })
        })
        .then(response => response.json())
        .then(result => {
            let obt = result.resultado;

            if(obt){
                app.preloader.hide();
                $$(".usuario_register").val("");
                $$(".nombre_register").val("");
                $$(".correo_register").val("");
                $$("#foto").attr("src", "");
                $$(".clave_register").val("");
                app.dialog.alert(obt, function(){
                    $$(".popup-close").click();
                });
            }
        })
        .catch(error => {
            app.preloader.hide();
            if (error instanceof TypeError && error.message === 'Failed to fetch') {
                app.dialog.alert("Para registrar un usuario Revise su conexión a internet");
            }
        });
    }
});