function obtenerUsuario(){
    var UserDataString = localStorage.getItem('UserData');
    var user = JSON.parse(UserDataString);
    return user;
}

export { obtenerUsuario };