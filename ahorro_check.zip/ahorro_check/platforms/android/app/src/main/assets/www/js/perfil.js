import { obtenerToken } from "../js/token.js";
import { obtenerUsuario } from "../js/usuario.js";

function listar_datos_perfil(){
    var user = obtenerUsuario();
    var id = user[0].id_usuario;
    var token = obtenerToken();

    app.preloader.show();

    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "listar_usuarios_por_id",
            id: id,
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
        let obt = result;

        if(obt){
            app.preloader.hide();
            $$(".usuario_data").val(obt[0].usuario);
            $$(".nombre_data").val(obt[0].nombre);
            $$(".correo_data").val(obt[0].email);
            $$(".id_usuario_data").val(obt[0].id_usuario);
            $$(".avatar").html("<img id='foto_perfil' src='"+ 'https://danielhuerta.cl' + obt[0].foto +"' width='90' />");
            $$(".user_name").text(obt[0].nombre);
            $$(".user_rol").text(obt[0].usuario);
            $$(".email_user").text(obt[0].email);
        }
    })
    .catch(error => {
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            //app.dialog.alert("Para cargar los datos del Perfil Revise su conexión a internet");
            setTimeout(function(){
                app.preloader.hide();
                $$(".usuario_data").val(user[0].usuario);
                $$(".nombre_data").val(user[0].nombre);
                $$(".correo_data").val(obt[0].email);
                $$(".id_usuario_data").val(user[0].id_usuario);
                $$(".avatar").html("<img id='foto_perfil' src='"+ 'https://danielhuerta.cl' + user[0].foto +"' width='90' />");
                $$(".user_name").text(user[0].nombre);
                $$(".user_rol").text(user[0].usuario);
                $$(".email_user").text(user[0].email);
            }, 1000);
        }
    });
}

export { listar_datos_perfil };

$$(document).on("click", ".actualizar_perfil", function(){
    let usuario = $$(".usuario_data").val();
    let nombre = $$(".nombre_data").val();
    let correo = $$(".correo_data").val();
    let clave = $$(".clave_data").val();
    let id_usuario = $$(".id_usuario_data").val();
    var token = obtenerToken();

    if(clave == ""){
        app.dialog.alert('La contraseña está vacia');
    } else {

        fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                accion: "actualizar_usuario",
                id_usuario: id_usuario,
                usuario: usuario,
                clave: clave,
                nombre: nombre,
                correo: correo,
                token: token
            })
        })
        .then(response => response.json())
        .then(result => {
            let obt = result.resultado;

            if(obt){
                app.preloader.hide();
                app.dialog.alert(obt, function(){
                    listar_datos_perfil();
                });
            }
        })
        .catch(error => {
            app.preloader.hide();
            if (error instanceof TypeError && error.message === 'Failed to fetch') {
                app.dialog.alert("Para Actualizar los datos del Perfil Revise su conexión a internet");
            }
        });
    }
});