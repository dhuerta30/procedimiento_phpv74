import { obtenerToken } from "../js/token.js";
import { obtenerUsuario } from "../js/usuario.js";

$$(document).on("popup:opened", ".agregar_tarea_popup", function(){
    var user = obtenerUsuario();
    $$(".titulo_tarea").val("");
    $$(".fecha_inicio_tarea").val("");
    $$(".fecha_fin_tarea").val("");
    $$(".contenido_tarea").val("");
    $$(".hora_tarea").val("");
    $$(".color_tarea").val("0");
    $$(".estado_tarea").val("");
    $$(".usuario_tarea").val(user[0].usuario);
});

// Función para cargar la lista de tareas
function cargarListaTareas() {
    var user = obtenerUsuario();
    let sesion_user = user[0].usuario;

    var token = obtenerToken();
    app.preloader.show();

    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "listar_tareas_datatable",
            token: token,
            usuario: sesion_user
        })
    })
    .then(response => response.json())
    .then(result => {
        app.preloader.hide();
        let request = result.data;

        if(request != ""){
            $('.cargar_agenda').empty();
            $.each(request.slice(0, 8), function(index, obj){

                var partesFecha = obj.fecha_inicio.split('-');
                var fechaFormateada = partesFecha[2] + '-' + partesFecha[1] + '-' + partesFecha[0];

                $('.sin_data').hide();
                $('.cargar_agenda').append(`
                    <li>
                        <a class="item-content">
                        <div class="item-media"><i class="f7-icons">pencil_ellipsis_rectangle</i></div>
                        <div class="item-inner">
                            <div class="item-title">
                                <div class="item-header">${obj.titulo}</div>
                                <span>${obj.hora}</span>
                                <div class="item-footer">${fechaFormateada}</div>
                            </div>
                            <div class="item-after">
                                <button class="button button-small popup-open editar_tarea_agenda" data-popup=".editar_poup_agenda" data-id="${obj.id_tareas}">
                                    <i class="f7-icons">eye</i>
                                </button>  
                            </div>  
                        </div>
                        </a>
                    </li>
                `);
            });
        } else {
            $(".top_agenda").html(`
                <div class="block sin_data">
                    <p>No se encontraron resultados</p>
                </div>
            `);
        }
    })
    .catch(error => {
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            setTimeout(function(){

                var datosLocalStorage = localStorage.getItem("data_tarea");
                var datos = JSON.parse(datosLocalStorage);

                var datosParaTareas = {
                    data: datos,
                };

                let request = datosParaTareas.data;

                $('.cargar_agenda').empty();
                $.each(request.slice(0, 8), function(index, obj){

                    var partesFecha = obj.desde.split('-');
                    var fechaFormateada = partesFecha[2] + '-' + partesFecha[1] + '-' + partesFecha[0];

                    $('.cargar_agenda').append(`
                        <li>
                            <a class="item-content">
                            <div class="item-media"><i class="f7-icons">pencil_ellipsis_rectangle</i></div>
                            <div class="item-inner">
                                <div class="item-title">
                                    <div class="item-header">${obj.titulo}</div>
                                    <span>${obj.hora}</span>
                                <div class="item-footer">${fechaFormateada}</div>
                                </div>
                                <div class="item-after">
                                    <button class="button button-small popup-open editar_tarea_agenda" data-popup=".editar_poup_agenda" data-id="${obj.id_tareas}">
                                        <i class="f7-icons">eye</i>
                                    </button>  
                                </div>  
                            </div>
                            </a>
                        </li>
                    `);
                });

            }, 1000);
        }
    });
}

export { cargarListaTareas };

let dataTable_tareas;

function cargarTareas() {
    var user = obtenerUsuario();
    let sesion_user = user[0].usuario;

    var token = obtenerToken();

    app.preloader.show();

    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "listar_tareas_datatable",
            token: token,
            usuario: sesion_user
        })
    })
    .then(response => response.json())
    .then(result => {
        let Tabla = result.data;
        
        app.preloader.hide();
        // Destruir el DataTable existente si ya existe
        if (dataTable_tareas) {
            dataTable_tareas.destroy();
        }

        // Llenar la tabla con los datos obtenidos y almacenar la referencia al DataTable
        dataTable_tareas = $('.table_tareas').DataTable({
            data: Tabla,
            pagingType: 'simple',
            searching: true,
            bLengthChange: false,
            scrollX: true,
            pageLength: 5,
            language: {
                "decimal": "",
                "emptyTable": "No hay información",
                "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
                "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
                "infoFiltered": "(Filtrado de _MAX_ total entradas)",
                "infoPostFix": "",
                "thousands": ",",
                "lengthMenu": "Mostrar _MENU_ Entradas",
                "loadingRecords": "Cargando...",
                "processing": "Procesando...",
                "search": "Buscar:",
                "zeroRecords": "Sin resultados encontrados",
                "paginate": {
                    "first": "Primero",
                    "last": "Ultimo",
                    "next": "<div class='f7-icons'>arrow_right_circle_fill</div>",
                    "previous": "<div class='f7-icons'>arrow_left_circle_fill</div>"
                }
            },
            columnDefs: [
                { targets: [0], className: 'numeric-cell' },
                { targets: [1], className: 'numeric-cell' },
                { targets: [2], className: 'numeric-cell' },
                { targets: [3], className: 'numeric-cell' },
                { targets: [4], className: 'numeric-cell' },
                { targets: [5], className: 'numeric-cell' },
                { targets: [6], className: 'numeric-cell' },
                { targets: [7], className: 'numeric-cell' },
                { targets: [8], orderable: false }
            ],
            columns: [
                { data: 'id_tareas' },
                { data: 'titulo' },
                { data: 'fecha_inicio',
                    render: function(data, type, row, meta){
                        var fecha = new Date(data);
                        if (isNaN(fecha.getTime())) { // Verifica si la fecha es un valor inválido
                            return "Sin Fecha"; // Si es un valor inválido, devuelve "Sin Fecha"
                        }
                        // Extraer los componentes de la fecha
                        var dia = fecha.getDate() + 1;
                        var mes = fecha.getMonth() + 1; // ¡Recuerda que los meses son indexados desde 0!
                        var año = fecha.getFullYear();
                        // Formatear la fecha en el formato deseado (d-m-Y)
                        var fechaFormateada = (dia < 10 ? '0' : '') + dia + '-' + (mes < 10 ? '0' : '') + mes + '-' + año;
                        return fechaFormateada;
                    } 
                },
                { data: 'fecha_fin',
                    render: function(data, type, row, meta){
                        var fecha = new Date(data);
                        if (isNaN(fecha.getTime())) { // Verifica si la fecha es un valor inválido
                            return "Sin Fecha"; // Si es un valor inválido, devuelve "Sin Fecha"
                        }
                        // Extraer los componentes de la fecha
                        var dia = fecha.getDate() + 1;
                        var mes = fecha.getMonth() + 1; // ¡Recuerda que los meses son indexados desde 0!
                        var año = fecha.getFullYear();
                        // Formatear la fecha en el formato deseado (d-m-Y)
                        var fechaFormateada = (dia < 10 ? '0' : '') + dia + '-' + (mes < 10 ? '0' : '') + mes + '-' + año;
                        return fechaFormateada;
                    }  
                },
                { data: 'hora' },
                { data: 'color_tarea' },
                { data: 'estado_tarea' },
                { data: 'usuario' },
                {
                    render: function(data, type, row, meta){
                        return ` <p class="grid grid-cols-2 grid-gap">
                                    <button class="button button-small button-fill editar_tarea" data-id="${row.id_tareas}"><span class="f7-icons">pencil</span></button>
                                    <button class="button button-small button-fill color-red eliminar_tarea" data-id="${row.id_tareas}"><span class="f7-icons">trash</span></button>
                                </p>`;
                    }
                }
            ]
        });
    })
    .catch(error => {
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            setTimeout(function(){
                cargarTareasLocalStorage();
            }, 1000);
        }
    });
}

export { cargarTareas };

let dataTable_tareasStorage;

function cargarTareasLocalStorage(){
    var datosLocalStorage = localStorage.getItem("data_tarea");
    var datos = JSON.parse(datosLocalStorage);

    var datosParaDataTable = {
        data: datos,
    };

    let Tabla = datosParaDataTable.data;

        // Destruir el DataTable existente si ya existe
        if (dataTable_tareasStorage) {
            dataTable_tareasStorage.destroy();
        }

        dataTable_tareasStorage = $('.table_tareas').DataTable({
        data: Tabla,
        pagingType: 'simple',
        searching: true,
        bLengthChange: false,
        scrollX: true,
        pageLength: 5,
        processing: true,
        serverside: true,
        language: {
            "decimal": "",
            "emptyTable": "No hay información",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
            "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
            "infoFiltered": "(Filtrado de _MAX_ total entradas)",
            "infoPostFix": "",
            "thousands": ",",
            "lengthMenu": "Mostrar _MENU_ Entradas",
            "loadingRecords": "Cargando...",
            "processing": "Procesando...",
            "search": "Buscar:",
            "zeroRecords": "Sin resultados encontrados",
            "paginate": {
                "first": "Primero",
                "last": "Ultimo",
                "next": "<div class='f7-icons'>arrow_right_circle_fill</div>",
                "previous": "<div class='f7-icons'>arrow_left_circle_fill</div>"
            }
        },
        columnDefs: [
            { targets: [0], className: 'numeric-cell' },
            { targets: [1], className: 'numeric-cell' },
            { targets: [2], className: 'numeric-cell' },
            { targets: [3], className: 'numeric-cell' },
            { targets: [4], className: 'numeric-cell' },
            { targets: [5], className: 'numeric-cell' },
            { targets: [6], className: 'numeric-cell' },
            { targets: [7], className: 'numeric-cell' },
            { targets: [8], orderable: false }
        ],
        columns: [
            { data: 'id_tareas' },
            { data: 'titulo' },
            { data: 'desde',
                render: function(data, type, row, meta){
                    var fecha = new Date(data);

                    if (isNaN(fecha.getTime())) { // Verifica si la fecha es un valor inválido
                        return "Sin Fecha"; // Si es un valor inválido, devuelve "Sin Fecha"
                    }
                    // Extraer los componentes de la fecha
                    var dia = fecha.getDate() + 1;
                    var mes = fecha.getMonth() + 1; // ¡Recuerda que los meses son indexados desde 0!
                    var año = fecha.getFullYear();
                    // Formatear la fecha en el formato deseado (d-m-Y)
                    var fechaFormateada = (dia < 10 ? '0' : '') + dia + '-' + (mes < 10 ? '0' : '') + mes + '-' + año;
                    return fechaFormateada;
                } 
            },
            { data: 'hasta',
                render: function(data, type, row, meta){
                    var fecha = new Date(data);

                    if (isNaN(fecha.getTime())) { // Verifica si la fecha es un valor inválido
                        return "Sin Fecha"; // Si es un valor inválido, devuelve "Sin Fecha"
                    }
                    // Extraer los componentes de la fecha
                    var dia = fecha.getDate() + 1;
                    var mes = fecha.getMonth() + 1; // ¡Recuerda que los meses son indexados desde 0!
                    var año = fecha.getFullYear();
                    // Formatear la fecha en el formato deseado (d-m-Y)
                    var fechaFormateada = (dia < 10 ? '0' : '') + dia + '-' + (mes < 10 ? '0' : '') + mes + '-' + año;
                    return fechaFormateada;
                }  
            },
            { data: 'hora' },
            { data: 'color' },
            { data: 'estado' },
            { data: 'usuario' },
            {
                render: function(data, type, row, meta){
                    return ` <p class="grid grid-cols-2 grid-gap">
                                <button class="button button-small button-fill editar_tarea" data-id="${row.id_tareas}"><span class="f7-icons">pencil</span></button>
                                <button class="button button-small button-fill color-red eliminar_tarea" data-id="${row.id_tareas}"><span class="f7-icons">trash</span></button>
                            </p>`;
                }
            }
        ],
        order: [[1, 'desc']]
    });
}

$$(document).on("change", ".color", function(){
    let color_tarea = $(this).val();
   
    if(color_tarea === 'green'){
      $('.estado').val('Completada');
    } else if(color_tarea === 'red'){
      $('.estado').val('Urgente');
    } else if(color_tarea === 'blue'){
      $('.estado').val('En espera');
    } else {
      $('.estado').val('No se Realizó');
    }
});


export { cargarTareasLocalStorage };

$$(document).on("click", ".guardar_tarea", function(e){
    e.preventDefault();

    let titulo = $$(".titulo_tarea").val();
    let fecha_inicio = $$(".fecha_inicio_tarea").val();
    let fecha_fin = $$(".fecha_fin_tarea").val();
    let contenido = $$(".contenido_tarea").val();
    let hora = $$(".hora_tarea").val();
    let color = $$(".color_tarea").val();
    let estado = $$(".estado_tarea").val();
    let usuario = $$(".usuario_tarea").val();

    if(color === 'green'){
        estado = 'Completada';
    } else if(color === 'red'){
        estado = 'Urgente';
    } else if(color === 'blue'){
        estado = 'En espera';
    } else {
        estado = 'No se Realizó';
    }

    var token = obtenerToken();

    fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            accion: "insertar_tareas",
            titulo: titulo,
            desde: fecha_inicio,
            hasta: fecha_fin,
            contenido: contenido,
            hora: hora,
            color_tarea: color,
            estado_tarea: estado,
            usuario_tarea: usuario,
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
        if (result.resultado) {
            $$('.titulo_tarea').val("");
            $$('.fecha_inicio_tarea').val("");
            $$('.fecha_fin_tarea').val("");
            $$('.contenido_tarea').val("");
            $$('.hora_tarea').val("");
            $$('.color_tarea').val("");
            $$('.usuario_tarea').val("");
            app.dialog.alert(result.resultado, function(){
                $$(".popup-close").click();

                cargarTareas();

                let tareas = JSON.parse(localStorage.getItem('data_tarea')) || [];
                tareas.push({
                    id_tareas: result.id_tareas,
                    titulo: titulo,
                    desde: fecha_inicio,
                    hasta: fecha_fin,
                    contenido: contenido,
                    hora: hora,
                    color: color,
                    estado: estado,
                    usuario: usuario
                });
                localStorage.setItem('data_tarea', JSON.stringify(tareas));
            });
        } else {
            // Mostrar mensaje de error
            app.dialog.alert(result.error);
        }
    })
    .catch(error => {
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            app.dialog.alert("Para Agregar esta Tarea Revise su conexión a internet");
        }
    });
});


function eliminarTareaLocalStorage(id) {
    // Obtener la lista de gastos del almacenamiento local
    let tareas = JSON.parse(localStorage.getItem('data_tarea')) || [];

    // Filtrar la lista para eliminar el gasto con el ID especificado
    tareas = tareas.filter(tarea => tarea.id_tareas !== id);

    // Guardar la lista actualizada en el almacenamiento local
    localStorage.setItem('data_tarea', JSON.stringify(tareas));
}

export { eliminarTareaLocalStorage };

$$(document).on("click", ".eliminar_tarea", function(){
    let id = $$(this).data("id");
    let token = obtenerToken();

    app.dialog.confirm('¿Estás seguro de eliminar esta tarea?', function(){
        // Muestra el spinner de carga antes de realizar la solicitud
        app.preloader.show();

        fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                accion: "eliminar_tareas",
                id: id,
                token: token
            })
        })
        .then(response => response.json())
        .then(result => {
            let obt = result.resultado;

            if(obt){
                app.preloader.hide();
                app.dialog.alert(obt, function(){
                    cargarTareas();
                    eliminarTareaLocalStorage(id);
                });
            }
        })
        .catch(error => {
            app.preloader.hide();
            if (error instanceof TypeError && error.message === 'Failed to fetch') {
                app.dialog.alert("Para Eliminar esta tarea Revise su conexión a internet");
            }
        });
    });
});


$$(document).on("click", ".editar_tarea", function(){
    let id = $$(this).data("id");
    let token = obtenerToken();

    app.preloader.show();
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "listar_tareas_por_id",
            id: id,
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
        let obt = result.resultado;

        app.popup.open('.editar_poup_tarea');

        $$(".titulo").val(obt[0].titulo);
        $$(".fecha_inicio").val(obt[0].fecha_inicio);
        $$(".fecha_fin").val(obt[0].fecha_fin);
        $$(".contenido").val(obt[0].contenido);
        $$(".hora").val(obt[0].hora);
        $$(".color").val(obt[0].color_tarea);
        $$(".estado").val(obt[0].estado_tarea);
        $$(".usuario").val(obt[0].usuario);
        $$(".id_tarea").val(obt[0].id_tareas);
        //cargar_motivos(obt[0].Motivo_de_compra);
        app.preloader.hide();
    })
    .catch(error => {
        app.preloader.hide();
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            app.dialog.alert("Para Mostrar los Datos Revise su conexión a internet");
        }
    });
});


$$(document).on("click", ".editar_tarea_agenda", function(){
    let id = $$(this).data("id");
    let token = obtenerToken();

    app.preloader.show();
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "listar_tareas_por_id",
            id: id,
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
        let obt = result.resultado;

        app.popup.open('.editar_poup_tarea');

        $$(".titulo_mod").val(obt[0].titulo);
        $$(".fecha_inicio_mod").val(obt[0].fecha_inicio);
        $$(".fecha_fin_mod").val(obt[0].fecha_fin);
        $$(".contenido_mod").val(obt[0].contenido);
        $$(".hora_mod").val(obt[0].hora);
        $$(".color_mod").val(obt[0].color_tarea);
        $$(".estado_mod").val(obt[0].estado_tarea);
        $$(".usuario_mod").val(obt[0].usuario);
        $$(".id_tarea_mod").val(obt[0].id_tareas);
        //cargar_motivos(obt[0].Motivo_de_compra);
        app.preloader.hide();
    })
    .catch(error => {
        app.preloader.hide();
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            app.dialog.alert("Para Mostrar los Datos Revise su conexión a internet");
        }
    });
});


$$(document).on("click", ".actualizar_tarea", function(){
    let id = $$('.id_tarea').val();
    let titulo = $$(".titulo").val();
    let fecha_inicio = $$(".fecha_inicio").val();
    let fecha_fin = $$(".fecha_fin").val();
    let contenido = $$(".contenido").val();
    let hora = $$(".hora").val();
    let color_tarea = $$(".color").val();
    let estado_tarea = $$(".estado").val();
    let token = obtenerToken();

    app.preloader.show();
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "modificar_tareas",
            id: id,
            titulo: titulo,
            contenido: contenido,
            fecha_inicio: fecha_inicio,
            fecha_fin: fecha_fin,
            hora: hora,
            color_tarea: color_tarea,
            estado_tarea: estado_tarea,
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
        let obt = result.resultado;

        if(obt){
            app.preloader.hide();
            app.dialog.alert(obt, function(){
                $$(".popup-close").click();
                cargarTareas();
            });
        }
    })
    .catch(error => {
        app.preloader.hide();
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            app.dialog.alert("Para Actualizar los Datos Revise su conexión a internet");
        }
    });
});

$$(document).on("click", ".modificar_tarea", function(){
    let id = $$('.id_tarea_mod').val();
    let titulo = $$(".titulo_mod").val();
    let fecha_inicio = $$(".fecha_inicio_mod").val();
    let fecha_fin = $$(".fecha_fin_mod").val();
    let contenido = $$(".contenido_mod").val();
    let hora = $$(".hora_mod").val();
    let color_tarea = $$(".color_mod").val();
    let estado_tarea = $$(".estado_mod").val();
    let token = obtenerToken();

    app.preloader.show();
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "modificar_tareas",
            id: id,
            titulo: titulo,
            contenido: contenido,
            fecha_inicio: fecha_inicio,
            fecha_fin: fecha_fin,
            hora: hora,
            color_tarea: color_tarea,
            estado_tarea: estado_tarea,
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
        let obt = result.resultado;

        if(obt){
            app.preloader.hide();
            app.dialog.alert(obt, function(){
                $$(".popup-close").click();
                cargarListaTareas();
            });
        }
    })
    .catch(error => {
        app.preloader.hide();
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            app.dialog.alert("Para Actualizar los Datos Revise su conexión a internet");
        }
    });
});