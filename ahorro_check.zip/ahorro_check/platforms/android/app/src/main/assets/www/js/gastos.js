import { obtenerToken } from "../js/token.js";
import { obtenerUsuario } from "../js/usuario.js";
import { cargar_motivos } from "../js/motivos.js";

$$(document).on("popup:opened", ".my-popup", function(){
    var user = obtenerUsuario();
    $$(".fecha").val("");
    $$(".producto").val("");
    $$(".motivo").val("");
    $$(".precio").val("");
    $$(".publicado").val(user[0].usuario);
    cargar_motivos();
});

let dataTable;

function cargarDatos() {
    var user = obtenerUsuario();
    let sesion_user = user[0].usuario;

    var token = obtenerToken();

    app.preloader.show();

    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "listar_gastos",
            token: token,
            usuario: sesion_user
        })
    })
    .then(response => response.json())
    .then(result => {
        let Tabla = result.data;

        // Destruir el DataTable existente si ya existe
        if (dataTable) {
            dataTable.destroy();
        }

        // Llenar la tabla con los datos obtenidos y almacenar la referencia al DataTable
        dataTable = $('.table').DataTable({
            data: Tabla,
            pagingType: 'simple',
            searching: true,
            bLengthChange: false,
            scrollX: true,
            pageLength: 5,
            processing: true,
            serverside: true,
            language: {
                "decimal": "",
                "emptyTable": "No hay información",
                "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
                "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
                "infoFiltered": "(Filtrado de _MAX_ total entradas)",
                "infoPostFix": "",
                "thousands": ",",
                "lengthMenu": "Mostrar _MENU_ Entradas",
                "loadingRecords": "Cargando...",
                "processing": "Procesando...",
                "search": "Buscar:",
                "zeroRecords": "Sin resultados encontrados",
                "paginate": {
                    "first": "Primero",
                    "last": "Ultimo",
                    "next": "<div class='f7-icons'>arrow_right_circle_fill</div>",
                    "previous": "<div class='f7-icons'>arrow_left_circle_fill</div>"
                }
            },
            columnDefs: [
                { targets: [0], className: 'numeric-cell' },
                { targets: [1], className: 'numeric-cell' },
                { targets: [2], className: 'numeric-cell' },
                { targets: [3], className: 'numeric-cell' },
                { targets: [4], className: 'numeric-cell' },
                { targets: [5], className: 'numeric-cell' },
                { targets: [6], orderable: false }
            ],
            columns: [
                { data: 'id_gastos' },
                { data: 'Fecha',
                    render: function(data, type, row, meta){
                        var fecha = moment(data);

                        if (!fecha.isValid()) { // Verifica si la fecha es un valor inválido
                            return "Sin Fecha"; // Si es un valor inválido, devuelve "Sin Fecha"
                        }
                        // Formatear la fecha en el formato deseado (d/m/y)
                        var fechaFormateada = fecha.format('DD/MM/Y');
                        return fechaFormateada;
                    } 
                },
                { data: 'Producto' },
                { data: 'Motivo_de_compra' },
                { data: 'precio' },
                { data: 'publicado_por' },
                {
                    render: function(data, type, row, meta){
                        return ` <p class="grid grid-cols-2 grid-gap">
                                    <button class="button button-small button-fill editar_gasto" data-id="${row.id_gastos}"><span class="f7-icons">pencil</span></button>
                                    <button class="button button-small button-fill color-red eliminar_gasto" data-id="${row.id_gastos}"><span class="f7-icons">trash</span></button>
                                </p>`;
                    }
                }
            ],
            order: [[0, 'desc']]
        });
        app.preloader.hide();
    })
    .catch(error => {
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            app.preloader.hide();
            cargarDatosLocalStorage();
        }
    });
}

export { cargarDatos };


let dataTableGastos;

function cargarDatosLocalStorage(){
    var datosLocalStorage = localStorage.getItem("data");
    var datos = JSON.parse(datosLocalStorage);

    var datosParaDataTable = {
        data: datos,
    };

    let Tabla = datosParaDataTable.data;

        // Destruir el DataTable existente si ya existe
        if (dataTableGastos) {
            dataTableGastos.destroy();
        }

        dataTableGastos = $('.table').DataTable({
        data: Tabla,
        pagingType: 'simple',
        searching: true,
        bLengthChange: false,
        scrollX: true,
        pageLength: 5,
        processing: true,
        serverside: true,
        language: {
            "decimal": "",
            "emptyTable": "No hay información",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
            "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
            "infoFiltered": "(Filtrado de _MAX_ total entradas)",
            "infoPostFix": "",
            "thousands": ",",
            "lengthMenu": "Mostrar _MENU_ Entradas",
            "loadingRecords": "Cargando...",
            "processing": "Procesando...",
            "search": "Buscar:",
            "zeroRecords": "Sin resultados encontrados",
            "paginate": {
                "first": "Primero",
                "last": "Ultimo",
                "next": "<div class='f7-icons'>arrow_right_circle_fill</div>",
                "previous": "<div class='f7-icons'>arrow_left_circle_fill</div>"
            }
        },
        columnDefs: [
            { targets: [0], className: 'numeric-cell' },
            { targets: [1], className: 'numeric-cell' },
            { targets: [2], className: 'numeric-cell' },
            { targets: [3], className: 'numeric-cell' },
            { targets: [4], className: 'numeric-cell' },
            { targets: [5], className: 'numeric-cell' },
            { targets: [6], orderable: false }
        ],
        columns: [
            { data: 'id_gastos' },
            { data: 'fecha',
                render: function(data, type, row, meta){
                    var fecha = moment(data);

                    if (!fecha.isValid()) { // Verifica si la fecha es un valor inválido
                        return "Sin Fecha"; // Si es un valor inválido, devuelve "Sin Fecha"
                    }
                    // Formatear la fecha en el formato deseado (d/m/y)
                    var fechaFormateada = fecha.format('DD/MM/Y');
                    return fechaFormateada;
                } 
            },
            { data: 'producto' },
            { data: 'motivo' },
            { data: 'precio' },
            { data: 'publicado' },
            {
                render: function(data, type, row, meta){
                    return ` <p class="grid grid-cols-2 grid-gap">
                                <button class="button button-small button-fill editar_gasto" data-id="${row.id_gastos}"><span class="f7-icons">pencil</span></button>
                                <button class="button button-small button-fill color-red eliminar_gasto" data-id="${row.id_gastos}"><span class="f7-icons">trash</span></button>
                            </p>`;
                }
            }
        ],
        order: [[0, 'desc']]
    });
}

export { cargarDatosLocalStorage };

$$(document).on("click", ".guardar_gastos", function(e){
    e.preventDefault();

    let Fecha = $$(".fecha_gasto").val();
    let Producto = $$(".producto_gasto").val();
    let Motivo_de_compra = $$(".motivo_gasto").val();
    let precio = $$(".precio_gasto").val();
    let publicado_por = $$(".publicado_gasto").val();

    var token = obtenerToken();

    if(Fecha == ""){
        app.dialog.alert("La fecha está vacia");
    } else if(Producto == ""){
        app.dialog.alert("El Producto está vacio");
    } else if(Motivo_de_compra == "0"){
        app.dialog.alert("El Motivo de Compra está vacio");
    } else if(precio == ""){
        app.dialog.alert("El Precio está vacio");
    } else {
        fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                accion: "insertar_gastos",
                fecha: Fecha,
                producto: Producto,
                motivo: Motivo_de_compra,
                precio: precio,
                publicado: publicado_por,
                token: token
            })
        })
        .then(response => response.json())
        .then(result => {
            // Verificar si la autenticación fue exitosa
            if (result.message) {                  
                $$('.fecha_gasto').val("");
                $$('.producto_gasto').val("");
                $$('.motivo_gasto').val("");
                $$('.precio_gasto').val("");  
                app.dialog.alert(result.message, function(){
                    $$(".popup-close").click();
                    cargarDatos();
                    // Guardar datos en localStorage
                    let gastos = JSON.parse(localStorage.getItem('data')) || [];
                    gastos.push({
                        id_gastos: result.id_gastos,
                        fecha: Fecha,
                        producto: Producto,
                        motivo: Motivo_de_compra,
                        precio: precio,
                        publicado: publicado_por
                    });
                    localStorage.setItem('data', JSON.stringify(gastos));

                });
            } else {
                // Mostrar mensaje de error
                app.dialog.alert(result.error);
            }
        })
        .catch(error => {
            if (error instanceof TypeError && error.message === 'Failed to fetch') {
                app.dialog.alert("Sin conexión a Internet");
            }
        });
    }
});


function eliminarGastoLocalStorage(id) {
    // Obtener la lista de gastos del almacenamiento local
    let gastos = JSON.parse(localStorage.getItem('data')) || [];

    // Filtrar la lista para eliminar el gasto con el ID especificado
    gastos = gastos.filter(gasto => gasto.id_gastos !== id);

    // Guardar la lista actualizada en el almacenamiento local
    localStorage.setItem('data', JSON.stringify(gastos));
}

export { eliminarGastoLocalStorage };


$$(document).on("click", ".eliminar_gasto", function(){
    let id = $$(this).data("id");
    let token = obtenerToken();

    app.dialog.confirm('¿Estás seguro de eliminar este gasto?', function(){
        // Muestra el spinner de carga antes de realizar la solicitud
        app.preloader.show();

        fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                accion: "eliminar_gastos",
                id: id,
                token: token
            })
        })
        .then(response => response.json())
        .then(result => {
            let obt = result.resultado;

            if(obt){
                app.preloader.hide();
                app.dialog.alert(obt, function(){
                    cargarDatos();
                    eliminarGastoLocalStorage(id);
                });
            }
        })
        .catch(error => {
            app.preloader.hide();
            if (error instanceof TypeError && error.message === 'Failed to fetch') {
                app.dialog.alert("Para Eliminar este gasto Revise su conexión a internet");
            }
        });
    });
});


$$(document).on("click", ".editar_gasto", function(){
    let id = $$(this).data("id");
    let token = obtenerToken();

    app.preloader.show();
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "listar_gastos_por_id",
            id: id,
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
        let obt = result.resultado;

        app.popup.open('.editar_poup_gasto');

        $$(".fecha").val(obt[0].Fecha);
        $$(".producto").val(obt[0].Producto);
        $$(".precio").val(obt[0].precio);
        $$(".publicado").val(obt[0].publicado_por);
        $$(".id_gasto").val(obt[0].id_gastos);
        cargar_motivos(obt[0].Motivo_de_compra);
        app.preloader.hide();
    })
    .catch(error => {
        app.preloader.hide();
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            app.dialog.alert("Para Modificar los gastos Revise su conexión a internet");
        }
    });
});

$$(document).on("click", ".actualizar_gastos", function(){
    let id = $$(".id_gasto").val();
    let Fecha = $$(".fecha").val();
    let Producto = $$(".producto").val();
    let Motivo_de_compra = $$(".motivo_edit").val();
    let precio = $$(".precio").val();
    let publicado_por = $$(".publicado").val();
    let token = obtenerToken();

    app.preloader.show();
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "actualizar_gastos",
            id: id,
            fecha: Fecha,
            producto: Producto,
            motivo: Motivo_de_compra,
            precio: precio,
            publicado: publicado_por,
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
        let obt = result.resultado;

        if(obt){
            app.preloader.hide();
            app.dialog.alert(obt, function(){
                $$(".popup-close").click();
                cargarDatos();
            });
        }
    })
    .catch(error => {
        app.preloader.hide();
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            app.dialog.alert("Para Actualizar los Datos Revise su conexión a internet");
        }
    });
});