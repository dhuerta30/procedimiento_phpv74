import { obtenerToken } from "../js/token.js";
import { obtenerUsuario } from "../js/usuario.js";

$$(document).on("popup:opened", ".agregar_popup_compra", function(){
    $$('.nombre_compra_add').val("");
    $$('.precio_compra_add').val("");
    $$('.codigo_barras_compra_add').val("");
    $$('.lugar_de_compra_add').val("0");
    cargar_lugar_de_compra();
});

let dataTable_inventario; // Variable para almacenar la referencia al DataTable

function cargarInventarioCompras() {
    var token = obtenerToken();

    app.preloader.show();

    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "listar_inventario_compras",
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
        let Tabla = result.data;

        // Destruir el DataTable existente si ya existe
        if (dataTable_inventario) {
            dataTable_inventario.destroy();
        }

        // Llenar la tabla con los datos obtenidos y almacenar la referencia al DataTable
        dataTable_inventario = $('.table_inventario').DataTable({
            data: Tabla,
            pagingType: 'simple',
            searching: true,
            bLengthChange: false,
            scrollX: true,
            processing: true,
            serverside: true,
            pageLength: 5,
            language: {
                "decimal": "",
                "emptyTable": "No hay información",
                "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
                "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
                "infoFiltered": "(Filtrado de _MAX_ total entradas)",
                "infoPostFix": "",
                "thousands": ",",
                "lengthMenu": "Mostrar _MENU_ Entradas",
                "loadingRecords": "Cargando...",
                "processing": "Procesando...",
                "search": "Buscar:",
                "zeroRecords": "Sin resultados encontrados",
                "paginate": {
                    "first": "Primero",
                    "last": "Ultimo",
                    "next": "<div class='f7-icons'>arrow_right_circle_fill</div>",
                    "previous": "<div class='f7-icons'>arrow_left_circle_fill</div>"
                }
            },
            columnDefs: [
                { targets: [0], className: 'numeric-cell' },
                { targets: [1], className: 'numeric-cell' },
                { targets: [2], className: 'numeric-cell' },
                { targets: [3], className: 'numeric-cell' },
                { targets: [4], className: 'numeric-cell' }
            ],
            columns: [
                { data: 'id_inventario_compras' },
                { data: 'nombre_inventario' },
                { data: 'precio_inventario' },
                { data: 'codigo_de_barras' },
                { data: 'lugar_de_compra' },
                {
                    render: function(data, type, row, meta){
                        return ` <p class="grid grid-cols-2 grid-gap">
                                    <button class="button button-small button-fill editar_inventario_compra" data-id="${row.id_inventario_compras}"><span class="f7-icons">pencil</span></button>
                                    <button class="button button-small button-fill color-red eliminar_compra" data-id="${row.id_inventario_compras}"><span class="f7-icons">trash</span></button>
                                </p>`;
                    }
                }
            ]
        });
        app.preloader.hide();
    })
    .catch(error => {
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            app.preloader.hide();
            setTimeout(function(){
                cargarInventarioComprasLocalStorage();
            }, 1000);
        }
    });
}

export { cargarInventarioCompras };

let dataTable_InventarioStorage; // Variable para almacenar la referencia al DataTable

function cargarInventarioComprasLocalStorage(){
    var datosLocalStorage = localStorage.getItem("data_inventario");
    var datos = JSON.parse(datosLocalStorage);

    var datosParaDataTable = {
        data: datos,
    };

    let Tabla = datosParaDataTable.data;

        // Destruir el DataTable existente si ya existe
        if (dataTable_InventarioStorage) {
            dataTable_InventarioStorage.destroy();
        }

        dataTable_InventarioStorage = $('.table_inventario').DataTable({
        data: Tabla,
        pagingType: 'simple',
        searching: true,
        bLengthChange: false,
        scrollX: true,
        pageLength: 5,
        processing: true,
        serverside: true,
        language: {
            "decimal": "",
            "emptyTable": "No hay información",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
            "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
            "infoFiltered": "(Filtrado de _MAX_ total entradas)",
            "infoPostFix": "",
            "thousands": ",",
            "lengthMenu": "Mostrar _MENU_ Entradas",
            "loadingRecords": "Cargando...",
            "processing": "Procesando...",
            "search": "Buscar:",
            "zeroRecords": "Sin resultados encontrados",
            "paginate": {
                "first": "Primero",
                "last": "Ultimo",
                "next": "<div class='f7-icons'>arrow_right_circle_fill</div>",
                "previous": "<div class='f7-icons'>arrow_left_circle_fill</div>"
            }
        },
        columnDefs: [
            { targets: [0], className: 'numeric-cell' },
            { targets: [1], className: 'numeric-cell' },
            { targets: [2], className: 'numeric-cell' },
            { targets: [3], className: 'numeric-cell' },
            { targets: [4], className: 'numeric-cell' }
        ],
        columns: [
            { data: 'id_inventario_compras' },
            { data: 'nombre_inventario' },
            { data: 'precio_inventario' },
            { data: 'codigo_de_barras' },
            { data: 'lugar_de_compra' },
            {
                render: function(data, type, row, meta){
                    return ` <p class="grid grid-cols-2 grid-gap">
                                <button class="button button-small button-fill editar_inventario_compra" data-id="${row.id_inventario_compras}"><span class="f7-icons">pencil</span></button>
                                <button class="button button-small button-fill color-red eliminar_compra" data-id="${row.id_inventario_compras}"><span class="f7-icons">trash</span></button>
                            </p>`;
                }
            }
        ]
    });
}

export { cargarInventarioComprasLocalStorage };

$$(document).on("click", ".guardar_inventario_compra", function(e){
    e.preventDefault();

    let nombre_compra = $$(".nombre_compra_add").val();
    let precio_compra = $$(".precio_compra_add").val();
    let codigo_barras = $$(".codigo_barras_compra_add").val();
    let lugar_de_compra = $$(".lugar_de_compra_add").val();
    var token = obtenerToken();

    if(nombre_compra == ""){
        app.dialog.alert('El Nombre Compra está vacio');
    } else if(precio_compra == ""){
        app.dialog.alert('El Precio Compra está vacio');
    } else if(codigo_barras == ""){
        app.dialog.alert('El Código de Barras está vacio');
    } else if(lugar_de_compra == "0"){
        app.dialog.alert('El Lugar de compra está vacio');
    } else {
        fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                accion: "insertar_inventario_compras",
                nombre_compra: nombre_compra,
                precio_compra: precio_compra,
                codigo_barras: codigo_barras,
                lugar_de_compra: lugar_de_compra,
                token: token
            })
        })
        .then(response => response.json())
        .then(result => {
            // Verificar si la autenticación fue exitosa
            if (result.resultado) {                  
                $$('.nombre_compra_add').val("");
                $$('.precio_compra_add').val("");
                $$('.codigo_barras_compra_add').val("");
                $$('.lugar_de_compra_add').val("0");
                app.dialog.alert(result.resultado, function(){
                    $$(".popup-close").click();
                    cargarInventarioCompras();

                    let inventario_compras = JSON.parse(localStorage.getItem('data_inventario')) || [];
                    inventario_compras.push({
                        id_inventario_compras: result.id_inventario_compras,
                        nombre_inventario: nombre_compra,
                        precio_inventario: precio_compra,
                        codigo_de_barras: codigo_barras,
                        lugar_de_compra: lugar_de_compra
                    });
                    localStorage.setItem('data_inventario', JSON.stringify(inventario_compras));
                });
            } else {
                // Mostrar mensaje de error
                app.dialog.alert(result.error);
            }
        })
        .catch(error => {
            app.preloader.hide();
            if (error instanceof TypeError && error.message === 'Failed to fetch') {
                app.dialog.alert("Para Agregar este Producto al Inventario de Compra Revise su conexión a internet");
            }
        });
    }
});


function eliminarInventarioComprasLocalStorage(id) {
    // Obtener la lista de gastos del almacenamiento local
    let inventario = JSON.parse(localStorage.getItem('data_inventario')) || [];

    // Filtrar la lista para eliminar el gasto con el ID especificado
    inventario = inventario.filter(inventario_compra => inventario_compra.id_inventario_compras !== id);

    // Guardar la lista actualizada en el almacenamiento local
    localStorage.setItem('data_inventario', JSON.stringify(inventario));
}

export { eliminarInventarioComprasLocalStorage };

$$(document).on("click", ".eliminar_compra", function(){
    let id = $$(this).data("id");
    let token = obtenerToken();

    app.dialog.confirm('¿Estás seguro de eliminar este Producto del Inventario de Compras?', function(){
        // Muestra el spinner de carga antes de realizar la solicitud
        app.preloader.show();

        fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                accion: "eliminar_inventario_compras",
                id: id,
                token: token
            })
        })
        .then(response => response.json())
        .then(result => {
            let obt = result.resultado;

            if(obt){
                app.preloader.hide();
                app.dialog.alert(obt, function(){
                    cargarInventarioCompras();
                    eliminarInventarioComprasLocalStorage(id);
                });
            }
        })
        .catch(error => {
            app.preloader.hide();
            if (error instanceof TypeError && error.message === 'Failed to fetch') {
                app.dialog.alert("Para Eliminar este Producto del Inventario de Compras Revise su conexión a internet");
            }
        });
    });
});

$$(document).on("click", ".editar_inventario_compra", function(){
    let id = $$(this).data("id");
    let token = obtenerToken();

    app.preloader.show();
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "listar_inventario_compras_por_id",
            id: id,
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
        let obt = result.resultado;

        app.popup.open('.editar_poup_compra');
        $$('.nombre_compra_edit').val(obt[0].nombre_inventario);
        $$('.precio_compra_edit').val(obt[0].precio_inventario);
        $$('.codigo_barras_compra_edit').val(obt[0].codigo_de_barras);
        $$('.id_inventario_compras_edit').val(obt[0].id_inventario_compras);
        cargar_lugar_de_compra(obt[0].lugar_de_compra);
        app.preloader.hide();
    })
    .catch(error => {
        app.preloader.hide();
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            app.dialog.alert("Para Mostrar los Datos Revise su conexión a internet");
        }
    });
});

$$(document).on("click", ".actualizar_inventario_compra", function(){
    let id = $$(".id_inventario_compras_edit").val();
    let nombre = $$(".nombre_compra_edit").val();
    let precio = $$('.precio_compra_edit').val();
    let codigo_barras =  $$('.codigo_barras_compra_edit').val();
    let lugar_de_compra =  $$('.lugar_de_compra_edit').val();
    let token = obtenerToken();

    app.preloader.show();
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "actualizar_inventario_compras",
            id: id,
            nombre: nombre,
            precio: precio,
            codigo_barras: codigo_barras,
            lugar_de_compra: lugar_de_compra,
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
        let obt = result.resultado;

        if(obt){
            app.preloader.hide();
            app.dialog.alert(result.resultado, function(){
                $$(".popup-close").click();
                cargarInventarioCompras();
            });
        }
    })
    .catch(error => {
        app.preloader.hide();
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            app.dialog.alert("Para Actualizar los Datos Revise su conexión a internet");
        }
    });
});

function cargar_lugar_de_compra(id = ''){
    var token = obtenerToken();

    app.preloader.show();
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "listar_lugar_de_compra",
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
         let obt = result.resultado;

         app.preloader.hide();
         $('.lugar_de_compra_add, .lugar_de_compra_edit').empty();
         $('.lugar_de_compra_add, .lugar_de_compra_edit').html(`<option value="0">Seleccione Lugar de Compra</option>`);
         $.each(obt, function(index, obj){
            $('.lugar_de_compra_add, .lugar_de_compra_edit').append(`
                <option value="${obj.lugar_de_compra}">${obj.lugar_de_compra}</option>
            `);
         });

         if (id !== '') {
            $('.lugar_de_compra_edit').val(id);
        } else {
            $('.lugar_de_compra_edit').val('0');
        }

    })
    .catch(error => {
        app.preloader.hide();
        if (error instanceof TypeError && error.message === 'Failed to fetch') {

            var datosLocalStorage = localStorage.getItem("data_motivos");
            var datos = JSON.parse(datosLocalStorage);

            var datosParaDataTable = {
                data: datos,
            };

            let obt = datosParaDataTable.data;

            $('.lugar_de_compra_add, .lugar_de_compra_edit').empty();
            $('.lugar_de_compra_add, .lugar_de_compra_edit').html(`<option value="0">Seleccione Lugar de Compra</option>`);
            $.each(obt, function(index, obj){
                $('.lugar_de_compra_add, .lugar_de_compra_edit').append(`
                    <option value="${obj.lugar_de_compra}">${obj.lugar_de_compra}</option>
                `);
            });
        }
    });
}
export { cargar_lugar_de_compra };