import { obtenerToken } from "../js/token.js";
import { cargar_lugar_de_compra } from "../js/inventario_compra.js";

$$(document).on("click", ".guardar_lugar_de_compra", function(e){
    e.preventDefault();

    let lugar_de_compra = $$(".form_lugar_de_compra_add").val();
    var token = obtenerToken();

    if(lugar_de_compra == ""){
        app.dialog.alert('El Lugar de compra está vacio');
    } else {
        fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                accion: "insertar_lugar_de_compras",
                lugar_de_compra: lugar_de_compra,
                token: token
            })
        })
        .then(response => response.json())
        .then(result => {
            // Verificar si la autenticación fue exitosa
            if (result.resultado) {                  
                $$('.form_lugar_de_compra_add').val("");
                app.dialog.alert(result.resultado, function(){
                    $$(".cerrar_popup_lugar_de_compra").click();
                    cargar_lugar_de_compra();

                    let lugar_de_compras_data = JSON.parse(localStorage.getItem('data_lugar_de_compra')) || [];
                    lugar_de_compras_data.push({
                        id_lugar_de_compra: result.id_lugar_de_compra,
                        lugar_de_compra: lugar_de_compra
                    });
                    localStorage.setItem('data_lugar_de_compra', JSON.stringify(lugar_de_compras_data));
                });
            } else {
                // Mostrar mensaje de error
                app.dialog.alert(result.error);
            }
        })
        .catch(error => {
            app.preloader.hide();
            if (error instanceof TypeError && error.message === 'Failed to fetch') {
                app.dialog.alert("Para Agregar este Lugar de Compra Revise su conexión a internet");
            }
        });
    }
});