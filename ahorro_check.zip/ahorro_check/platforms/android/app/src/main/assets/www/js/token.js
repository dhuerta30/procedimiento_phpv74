function obtenerToken(){
    var tokenDataString = localStorage.getItem('tokenData');
    var token = JSON.parse(tokenDataString);
    return token;
}

export { obtenerToken };