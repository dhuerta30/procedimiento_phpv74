import { obtenerToken } from "../js/token.js";
import { obtenerUsuario } from "../js/usuario.js";

function obtener_gasto_por_semana_actual(){
    var token = obtenerToken();
    var user = obtenerUsuario();
    let sesion_user = user[0].usuario;

    app.preloader.show();

    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "obtener_gasto_por_semana_actual",
            token: token,
            usuario: sesion_user
        })
    })
    .then(response => response.json())
    .then(result => {
        let obt = result.resultado;

        if(obt){
            app.preloader.hide();
            $$(".datos_semanal").text(obt);
            
        }
    })
    .catch(error => {
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            //app.dialog.alert("Para cargar los datos del Perfil Revise su conexión a internet");
            setTimeout(function(){
                app.preloader.hide();
            }, 1000);
        }
    });
}

export { obtener_gasto_por_semana_actual };


function obtener_gasto_por_ano_actual(){
    var token = obtenerToken();
    var user = obtenerUsuario();
    let sesion_user = user[0].usuario;

    app.preloader.show();

    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "obtener_gasto_por_ano_actual",
            token: token,
            usuario: sesion_user
        })
    })
    .then(response => response.json())
    .then(result => {
        let obt = result.resultado;

        if(obt){
            app.preloader.hide();
            $$(".datos_ano").text(obt);
            
        }
    })
    .catch(error => {
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            //app.dialog.alert("Para cargar los datos del Perfil Revise su conexión a internet");
            setTimeout(function(){
                app.preloader.hide();
            }, 1000);
        }
    });
}

export { obtener_gasto_por_ano_actual };


function obtener_gasto_por_mes_actual(){
    var token = obtenerToken();
    var user = obtenerUsuario();
    let sesion_user = user[0].usuario;

    app.preloader.show();

    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "obtener_gasto_por_mes_actual",
            token: token,
            usuario: sesion_user
        })
    })
    .then(response => response.json())
    .then(result => {
        let obt = result.resultado;

        if(obt){
            app.preloader.hide();
            $$(".data_mes").text(obt);
            
        }
    })
    .catch(error => {
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            //app.dialog.alert("Para cargar los datos del Perfil Revise su conexión a internet");
            setTimeout(function(){
                app.preloader.hide();
            }, 1000);
        }
    });
}

export { obtener_gasto_por_mes_actual };