
document.addEventListener("deviceready", function() {
  mostrar_notificaciones();
}, false);

function OneSignalInit() {
    // Remove this method to stop OneSignal Debugging
    window.plugins.OneSignal.Debug.setLogLevel(6);
    // Replace YOUR_ONESIGNAL_APP_ID with your OneSignal App ID
    window.plugins.OneSignal.initialize("8101a62b-c098-4a4b-9fd5-bb2dbeea24fa");
    // Prompts the user for notification permissions.
    window.plugins.OneSignal.promptForPushNotificationsWithUserResponse();
}

function mostrar_notificaciones(){
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        accion: 'obtener_notificaciones'
      })
    })
  .then(response => response.json())
  .then(result => { 

    if(result){
        var app_id = result.notificaciones[0].id_notificaciones;
        var app_titulo = result.notificaciones[0].titulo;
        var app_fecha = result.notificaciones[0].fecha;
        var app_imagen = result.notificaciones[0].imagen;
        var app_contenido = result.notificaciones[0].contenido;
        var app_url = result.notificaciones[0].url;
         
        var notification = app.notification.create({
          icon: '<img width="30" src="'+app_imagen+'">',
          title: app_titulo,
          titleRightText: app_fecha,
          subtitle: app_contenido,
          text: 'Click (x) para cerrar',
          closeButton: true,
          on: {
            close: function () {
              actualizar_estado_notificacion(app_id);
              mostrar_notificaciones();
            },
            click: function () {
                viewHome.router.navigate(app_url);
            },
          },
        });
        notification.open();
    }


  })
  .catch(error => {

    if (error instanceof TypeError && error.message === 'Failed to fetch') {
      app.dialog.alert('Para Enviar una Notificación Revise su conexión a internet');
    }
  });
}

function actualizar_estado_notificacion(id){
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        accion: 'actualizar_estado_notificacion',
        id: id
      })
    })
  .then(response => response.json())
  .then(result => { 

    if(result){
        console.log("actualizado");
    }

  })
  .catch(error => {

    if (error instanceof TypeError && error.message === 'Failed to fetch') {
      app.dialog.alert('Para Enviar una Notificación Revise su conexión a internet');
    }
  });
}

function tomarFoto(imageElementId) {
    // Opciones para la cámara
    var options = {
        quality: 50, // Calidad de la imagen (0-100)
        destinationType: Camera.DestinationType.DATA_URL,
        sourceType: Camera.PictureSourceType.CAMERA, // Fuente de la imagen (cámara)
        encodingType: Camera.EncodingType.JPEG, // Tipo de codificación de la imagen
        correctOrientation: true,
        saveToPhotoAlbum: true,
        cameraDirection: Camera.Direction.FRONT
    };

    // Llamar a la función 'getPicture' del complemento de la cámara para capturar la foto
    navigator.camera.getPicture(function(imageURI) {
        onSuccess(imageURI, imageElementId);
    }, onError, options);
}

// Función de éxito: Se llama cuando se captura la foto correctamente
function onSuccess(imageData, imageElementId) {
  var image = document.getElementById(imageElementId);
  image.src = "data:image/jpeg;base64," + imageData;
}


// Función de error: Se llama cuando hay un problema al capturar la foto
function onError(message) {
    console.error('Error al capturar la foto:', message);
}
// Asociar el evento a los botones
document.getElementById('hacer_foto').addEventListener('click', function() {
    tomarFoto('foto');
});

$(document).on('click', '#tomar_foto', function() {
    tomarFoto('foto_perfil');
});

$(document).on('click', '#hacer_foto_inventario_add', function() {
  tomarFoto('foto_producto_inventario_add');
});

$(document).on('click', '#hacer_foto_inventario_edit', function() {
  tomarFoto('foto_producto_inventario_edit');
});
