import { cargarDatos } from "../js/gastos.js";
import { cargarMotivos } from "../js/motivos.js";
import { listar_datos_perfil } from "../js/perfil.js";
import { cargarInventarioCompras } from "../js/inventario_compra.js";
import { obtener_gasto_por_semana_actual, obtener_gasto_por_ano_actual, obtener_gasto_por_mes_actual } from "../js/home.js";

function loadDataAndHandleConnection(loadFunctions, done) {
    function loadMore() {
        loadFunctions.forEach(func => func());
        done();
    }

    function conexion() {
        if (navigator.onLine) {
            loadMore();
        } else {
            app.dialog.alert('Revise su conexión a internet');
            done();
        }
    }
    conexion();
}

// Define los eventos ptr:refresh
$$(document).on("ptr:refresh", ".top_agenda", function(e, done) {
    loadDataAndHandleConnection([cargarListaTareas], done);
});

$$(document).on("ptr:refresh", ".gastos_refresh", function(e, done) {
    loadDataAndHandleConnection([cargarDatos], done);
});

$$(document).on("ptr:refresh", ".home_refresh", function(e, done) {
    loadDataAndHandleConnection([obtener_gasto_por_semana_actual, obtener_gasto_por_ano_actual, obtener_gasto_por_mes_actual], done);
});

$$(document).on("ptr:refresh", ".perfil_refresh", function(e, done){
    loadDataAndHandleConnection([listar_datos_perfil], done);
});

$$(document).on("ptr:refresh", ".refresh_motivo", function(e, done){
    loadDataAndHandleConnection([cargarMotivos], done);
});

$$(document).on("ptr:refresh", ".refresh_inventario", function(e, done){
    loadDataAndHandleConnection([cargarInventarioCompras], done);
});

$$(document).on("ptr:refresh", ".login_refresh", function(e, done){
    app.preloader.show();
    setTimeout(function(){
        $$(".username").val("");
        $$(".password").val("");
        $$(".recordar_usuario").prop("checked", false);

        $$(".usuario_register").val("");
        $$(".nombre_register").val("");
        $$(".correo_register").val("");
        $$("#foto").attr("src", "");
        $$(".mostrar_foto_registrar_usuario").html("<img id='foto' src='images/avatar.jpg' width='100%'>");
        $$(".clave_register").val("");

        done();
        app.preloader.hide();
    }, 2000);
});