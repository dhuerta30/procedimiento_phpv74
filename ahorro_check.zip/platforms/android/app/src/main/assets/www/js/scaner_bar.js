import { obtenerToken } from "../js/token.js";
import { obtenerUsuario } from "../js/usuario.js";

var alertShown = false;

function playScannerSound() {
    var audio = document.getElementById("scannerSound");
    audio.play();
}

function obtenerMotivos(){
    var user = obtenerUsuario();
    let sesion_user = user[0].usuario;

    var token = obtenerToken();

    app.preloader.show();
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "listar_motivos_de_compra",
            token: token,
            usuario: sesion_user
        })
    })
    .then(response => response.json())
    .then(result => {
         let obt = result.data;

         app.preloader.hide();
         $('.motivo_gasto_add').empty();
         $('.motivo_gasto_add').html(`<option value="0">Seleccione Motivo de Compra</option>`);
         $.each(obt, function(index, obj){
            $('.motivo_gasto_add').append(`
                <option value="${obj.nombre}">${obj.nombre}</option>
            `);
         });
    });
}

function obtener_lugar_de_compra(){
    var token = obtenerToken();

    app.preloader.show();
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "listar_lugar_de_compra",
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
         let obt = result.resultado;

         app.preloader.hide();
         $('.lugar_de_compra_list').empty();
         $('.lugar_de_compra_list').html(`<option value="0">Seleccione Lugar de Compra</option>`);
         $.each(obt, function(index, obj){
            $('.lugar_de_compra_list').append(`
                <option value="${obj.lugar_de_compra}">${obj.lugar_de_compra}</option>
            `);
         });
    })
    .catch(error => {
        app.preloader.hide();
        if (error instanceof TypeError && error.message === 'Failed to fetch') {

            var datosLocalStorage = localStorage.getItem("data_lugar_de_compra");
            var datos = JSON.parse(datosLocalStorage);

            var datosParaDataTable = {
                data: datos,
            };

            let obt = datosParaDataTable.data;

            $('.lugar_de_compra_list').empty();
            $('.lugar_de_compra_list').html(`<option value="0">Seleccione Lugar de Compra</option>`);
            $.each(obt, function(index, obj){
                $('.lugar_de_compra_list').append(`
                    <option value="${obj.lugar_de_compra}">${obj.lugar_de_compra}</option>
                `);
            });
        }
    });
}

function onScanSuccess(decodedText) {  
    if (!alertShown) {
        alertShown = true;
        playScannerSound();
        
        app.dialog.create({
            title: '¿Desea Continuar con el Escaner?',
            buttons: [
                {
                    text: 'Cancelar',
                    onClick: function() {
                        alertShown = false; // Restablece el estado del indicador de alerta
                    }
                },
                {
                    text: 'Aceptar',
                    cssClass: 'btn-aceptar',
                    onClick: function () {
                        let codigo_de_barras = decodedText;

                        let selectOptions = `
                            <select style='padding:10px; border: 1px solid #c3c3c3; margin-top:10px; margin-bottom:10px; width:100%;' class="lugar_de_compra_list"></select>
                            <select style='padding:10px; border: 1px solid #c3c3c3; margin-top:10px; margin-bottom: 10px; width:100%;' class="motivo_gasto_add"></select>
                            <input type="text" style="padding:10px; border: 1px solid #c3c3c3; margin-top:10px; margin-bottom:10px; width:100%;" class="cantidad_producto" placeholder="Ingrese cantidad" value="1">
                            <label>Ingrese Fecha</label>
                            <input type="date" style="padding:10px; border: 1px solid #c3c3c3; width:100%;" class="fecha_actual">`;

                        obtener_lugar_de_compra();
                        obtenerMotivos();

                        // Función para ejecutar el fetch para insertar los gastos
                        function insertarGastos(producto_inventario, precio_inventario) {
                            let token = obtenerToken();
                            let motivo_gasto = $$('.motivo_gasto_add').val();
                           
                            let cantidad_producto = $$('.cantidad_producto').val();
                            let total = cantidad_producto * parseFloat(precio_inventario);

                            let fecha = $$('.fecha_actual').val();
                            var user = obtenerUsuario();
                            let sesion_user = user[0].usuario;

                            app.preloader.show();

                            fetch(url, {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/json"
                                },
                                body: JSON.stringify({
                                    accion: "insertar_gastos",
                                    fecha: fecha,
                                    producto: producto_inventario,
                                    motivo: motivo_gasto,
                                    precio: total,
                                    publicado: sesion_user,
                                    token: token
                                })
                            })
                            .then(response => response.json())
                            .then(respuesta => {
                                app.preloader.hide();
                                
                                if (respuesta.message) {
                                    let gastos = JSON.parse(localStorage.getItem('data')) || [];
                                    gastos.push({
                                        id_gastos: respuesta.id_gastos,
                                        fecha: fecha,
                                        producto: producto_inventario,
                                        motivo: motivo_gasto,
                                        precio: total,
                                        publicado: sesion_user
                                    });
                                    localStorage.setItem('data', JSON.stringify(gastos));

                                    $$('.lugar_de_compra_list').val("");
                                    $$('.motivo_gasto_add').val("");
                                    $$('.fecha_actual').val("");
                                    app.dialog.alert(respuesta.message);
                                } else {
                                    app.dialog.alert(respuesta.error || "Ocurrió un error al procesar tu solicitud.");
                                }
                            })
                            .catch(error => {
                                app.preloader.hide();
                                if (error instanceof TypeError && error.message === 'Failed to fetch') {
                                    
                                    app.dialog.alert("Sin conexión a Internet. Los datos se guardarán localmente.");
                                    let gastos = JSON.parse(localStorage.getItem('data')) || [];
                                    gastos.push({
                                        fecha: fecha,
                                        producto: producto_inventario,
                                        motivo: motivo_gasto,
                                        precio: total,
                                        publicado: sesion_user
                                    });
                                    localStorage.setItem('data', JSON.stringify(gastos));
                                    $$('.lugar_de_compra_list').val("");
                                    $$('.motivo_gasto_add').val("");
                                    $$('.fecha_actual').val("");
                                }
                            }); 
                        }

                        function dialogOpen() {
                            dialog.close();
                            dialog.open();
                        }

                        // Validar campos antes de insertar gastos y luego insertar gastos
                        var dialog = app.dialog.create({
                            title: 'Rellene para continuar',
                            content: selectOptions,
                            buttons: [
                                {
                                    text: 'Cancelar'
                                },
                                {
                                    text: 'Aceptar',
                                    onClick: function () {
                                        let lugar_de_compra = $$('.lugar_de_compra_list').val();
                                        let motivo_gasto = $$('.motivo_gasto_add').val();
                                        let cantidad_producto = $$('.cantidad_producto').val();
                                        let fecha = $$('.fecha_actual').val();
                                        let token = obtenerToken();

                                        if (lugar_de_compra == "0") {
                                            app.dialog.alert("El Lugar de Compra está vacío", dialogOpen);
                                        } else if (motivo_gasto == "0") {
                                            app.dialog.alert("El Motivo de Compra está vacío", dialogOpen);
                                        } else if (cantidad_producto == "") {
                                            app.dialog.alert("La cantidad del Producto está vacía", dialogOpen);
                                        } else if (fecha == "") {
                                            app.dialog.alert("La Fecha está vacía", dialogOpen);
                                        } else {
                                            // Obtener el producto y su precio antes de insertar gastos
                                            app.preloader.show();
                                            fetch(url, {
                                                method: "POST",
                                                headers: {
                                                    "Content-Type": "application/json"
                                                },
                                                body: JSON.stringify({
                                                    accion: "listar_inventario_compras_por_codigo_de_barras_y_lugar_de_compra",
                                                    token: token,
                                                    codigo_de_barras: codigo_de_barras,
                                                    lugar_de_compra: lugar_de_compra
                                                })
                                            })
                                            .then(response => response.json())
                                            .then(result => {
                                                app.preloader.hide();
                                                let datos = result.resultado;
                                                if (datos) {
                                                    let producto_inventario = datos[0].nombre_inventario;
                                                    let precio_inventario = datos[0].precio_inventario;
                                                    insertarGastos(producto_inventario, precio_inventario);
                                                } else {
                                                    app.dialog.alert('No se Encontró el Producto en el inventario');
                                                }
                                            })
                                            .catch(error => {
                                                app.preloader.hide();
                                                app.dialog.alert("Error al procesar tu solicitud. Por favor, inténtalo de nuevo más tarde.");
                                                console.error("Error al buscar producto en el inventario:", error);
                                            });
                                        }
                                    }
                                }
                            ],
                            on: {
                                closed: function() {
                                    alertShown = false;
                                }
                            }
                        }).open();
                    }
                }
            ]
        }).open();
    }
}

function startScanner(){
    let html5QrcodeScanner = new Html5QrcodeScanner("qr-reader", {
        fps: 60,
        qrbox: { width: 250, height: 250 },
        rememberLastUsedCamera: true,
        aspectRatio: 1 / 1,
        showTorchButtonIfSupported: true,
        showZoomSliderIfSupported: true,
        defaultZoomValueIfSupported: 2,
        supportedScanTypes: [Html5QrcodeScanType.SCAN_TYPE_CAMERA]
    });
    html5QrcodeScanner.render(onScanSuccess);
}

// gastos
$$(document).on('click', '#scanButton', function () {
    startScanner();
});

$$(document).on('click', '#cerrar_escaner', function () {
    $$("#html5-qrcode-button-camera-stop").click();
});


function startScannerHome(){
    let html5QrcodeScannerHome = new Html5QrcodeScanner("qr-reader-home", {
        fps: 60,
        qrbox: { width: 250, height: 250 },
        rememberLastUsedCamera: true,
        aspectRatio: 1 / 1,
        showTorchButtonIfSupported: true,
        showZoomSliderIfSupported: true,
        defaultZoomValueIfSupported: 2,
        supportedScanTypes: [Html5QrcodeScanType.SCAN_TYPE_CAMERA]
    });
    html5QrcodeScannerHome.render(onScanSuccess);
}

// home
$$(document).on('click', '#scanButtonHome', function () {
    startScannerHome();
});

$$(document).on('click', '#cerrar_escaner_home', function () {
    $$("#html5-qrcode-button-camera-stop").click();
});