import { obtenerToken } from "../js/token.js";
import { cargar_lugar_de_compra } from "../js/inventario_compra.js";


let dataTable;

function cargarLugarDeCompraGrilla() {
    var token = obtenerToken();

    app.preloader.show();

    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "listar_lugar_de_compra",
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
        let Tabla = result.data;

        // Destruir el DataTable existente si ya existe
        if (dataTable) {
            dataTable.destroy();
        }

        // Llenar la tabla con los datos obtenidos y almacenar la referencia al DataTable
        dataTable = $('.table_lugar_de_compra').DataTable({
            data: Tabla,
            pagingType: 'simple',
            searching: true,
            bLengthChange: false,
            scrollX: true,
            pageLength: 5,
            processing: true,
            serverside: true,
            language: {
                "decimal": "",
                "emptyTable": "No hay información",
                "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
                "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
                "infoFiltered": "(Filtrado de _MAX_ total entradas)",
                "infoPostFix": "",
                "thousands": ",",
                "lengthMenu": "Mostrar _MENU_ Entradas",
                "loadingRecords": "Cargando...",
                "processing": "Procesando...",
                "search": "Buscar:",
                "zeroRecords": "Sin resultados encontrados",
                "paginate": {
                    "first": "Primero",
                    "last": "Ultimo",
                    "next": "<div class='f7-icons'>arrow_right_circle_fill</div>",
                    "previous": "<div class='f7-icons'>arrow_left_circle_fill</div>"
                }
            },
            columnDefs: [
                { targets: [0], className: 'numeric-cell' },
                { targets: [1], className: 'numeric-cell' }
            ],
            columns: [
                { data: 'id_lugar_de_compra' },
                { data: 'lugar_de_compra' },
                {
                    render: function(data, type, row, meta){
                        return ` <p class="grid grid-cols-2 grid-gap">
                                    <button class="button button-small button-fill editar_lugar_de_compra" data-id="${row.id_lugar_de_compra}"><span class="f7-icons">pencil</span></button>
                                    <button class="button button-small button-fill color-red eliminar_lugar_de_compra" data-id="${row.id_lugar_de_compra}"><span class="f7-icons">trash</span></button>
                                </p>`;
                    }
                }
            ]
        });
        app.preloader.hide();
    })
    .catch(error => {
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            app.preloader.hide();
            cargarLugarDeCompraGrillaLocalStorage();
        }
    });
}

export { cargarLugarDeCompraGrilla };


let dataTableLugar;

function cargarLugarDeCompraGrillaLocalStorage(){
    var datosLocalStorage = localStorage.getItem("data");
    var datos = JSON.parse(datosLocalStorage);

    var datosParaDataTable = {
        data: datos,
    };

    let Tabla = datosParaDataTable.data;

        // Destruir el DataTable existente si ya existe
        if (dataTableLugar) {
            dataTableLugar.destroy();
        }

        dataTableLugar = $('.table_lugar_de_compra').DataTable({
        data: Tabla,
        pagingType: 'simple',
        searching: true,
        bLengthChange: false,
        scrollX: true,
        pageLength: 5,
        processing: true,
        serverside: true,
        language: {
            "decimal": "",
            "emptyTable": "No hay información",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
            "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
            "infoFiltered": "(Filtrado de _MAX_ total entradas)",
            "infoPostFix": "",
            "thousands": ",",
            "lengthMenu": "Mostrar _MENU_ Entradas",
            "loadingRecords": "Cargando...",
            "processing": "Procesando...",
            "search": "Buscar:",
            "zeroRecords": "Sin resultados encontrados",
            "paginate": {
                "first": "Primero",
                "last": "Ultimo",
                "next": "<div class='f7-icons'>arrow_right_circle_fill</div>",
                "previous": "<div class='f7-icons'>arrow_left_circle_fill</div>"
            }
        },
        columnDefs: [
            { targets: [0], className: 'numeric-cell' },
            { targets: [1], className: 'numeric-cell' }
        ],
        columns: [
            { data: 'id_lugar_de_compra' },
            { data: 'lugar_de_compra' },
            {
                render: function(data, type, row, meta){
                    return ` <p class="grid grid-cols-2 grid-gap">
                                <button class="button button-small button-fill editar_lugar_de_compra" data-id="${row.id_lugar_de_compra}"><span class="f7-icons">pencil</span></button>
                                <button class="button button-small button-fill color-red eliminar_lugar_de_compra" data-id="${row.id_lugar_de_compra}"><span class="f7-icons">trash</span></button>
                            </p>`;
                }
            }
        ]
    });
}

export { cargarLugarDeCompraGrillaLocalStorage };


$$(document).on("click", ".guardar_lugar_de_compra", function(e){
    e.preventDefault();

    let lugar_de_compra = $$(".form_lugar_de_compra_add").val();
    var token = obtenerToken();

    if(lugar_de_compra == ""){
        app.dialog.alert('El Lugar de compra está vacio');
    } else {
        fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                accion: "insertar_lugar_de_compras",
                lugar_de_compra: lugar_de_compra,
                token: token
            })
        })
        .then(response => response.json())
        .then(result => {
            // Verificar si la autenticación fue exitosa
            if (result.resultado) {                  
                $$('.form_lugar_de_compra_add').val("");
                app.dialog.alert(result.resultado, function(){
                    $$(".cerrar_popup_lugar_de_compra").click();
                    cargar_lugar_de_compra();

                    let lugar_de_compras_data = JSON.parse(localStorage.getItem('data_lugar_de_compra')) || [];
                    lugar_de_compras_data.push({
                        id_lugar_de_compra: result.id_lugar_de_compra,
                        lugar_de_compra: lugar_de_compra
                    });
                    localStorage.setItem('data_lugar_de_compra', JSON.stringify(lugar_de_compras_data));
                });
            } else {
                // Mostrar mensaje de error
                app.dialog.alert(result.error);
            }
        })
        .catch(error => {
            app.preloader.hide();
            if (error instanceof TypeError && error.message === 'Failed to fetch') {
                app.dialog.alert("Para Agregar este Lugar de Compra Revise su conexión a internet");
            }
        });
    }
});

function eliminarLugarDeCompraGrillaLocalStorage(id) {
    // Obtener la lista de gastos del almacenamiento local
    let lugar_de_compra = JSON.parse(localStorage.getItem('data_lugar_de_compra')) || [];

    // Filtrar la lista para eliminar el gasto con el ID especificado
    lugar_de_compra = lugar_de_compra.filter(lugar_de_compras => lugar_de_compras.id_lugar_de_compra !== id);

    // Guardar la lista actualizada en el almacenamiento local
    localStorage.setItem('data_lugar_de_compra', JSON.stringify(lugar_de_compra));
}

export { eliminarLugarDeCompraGrillaLocalStorage };


$$(document).on("click", ".eliminar_lugar_de_compra", function(){
    let id = $$(this).data("id");
    let token = obtenerToken();

    app.dialog.confirm('¿Estás seguro de eliminar este lugar de compra?', function(){
        // Muestra el spinner de carga antes de realizar la solicitud
        app.preloader.show();

        fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                accion: "eliminar_lugar_de_compra",
                id: id,
                token: token
            })
        })
        .then(response => response.json())
        .then(result => {
            let obt = result.resultado;

            if(obt){
                app.preloader.hide();
                app.dialog.alert(obt, function(){
                    cargarLugarDeCompraGrilla();
                    eliminarLugarDeCompraGrillaLocalStorage(id);
                });
            }
        })
        .catch(error => {
            app.preloader.hide();
            if (error instanceof TypeError && error.message === 'Failed to fetch') {
                app.dialog.alert("Para Eliminar este lugar de compra Revise su conexión a internet");
            }
        });
    });
});


$$(document).on("click", ".editar_gasto", function(){
    let id = $$(this).data("id");
    let token = obtenerToken();

    app.preloader.show();
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "listar_gastos_por_id",
            id: id,
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
        let obt = result.resultado;

        app.popup.open('.editar_poup_gasto');

        $$(".fecha").val(obt[0].Fecha);
        $$(".producto").val(obt[0].Producto);
        $$(".precio").val(obt[0].precio);
        $$(".publicado").val(obt[0].publicado_por);
        $$(".id_gasto").val(obt[0].id_gastos);
        cargar_motivos(obt[0].Motivo_de_compra);
        app.preloader.hide();
    })
    .catch(error => {
        app.preloader.hide();
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            app.dialog.alert("Para Modificar los gastos Revise su conexión a internet");
        }
    });
});

$$(document).on("click", ".actualizar_gastos", function(){
    let id = $$(".id_gasto").val();
    let Fecha = $$(".fecha").val();
    let Producto = $$(".producto").val();
    let Motivo_de_compra = $$(".motivo_edit").val();
    let precio = $$(".precio").val();
    let publicado_por = $$(".publicado").val();
    let token = obtenerToken();

    app.preloader.show();
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accion: "actualizar_gastos",
            id: id,
            fecha: Fecha,
            producto: Producto,
            motivo: Motivo_de_compra,
            precio: precio,
            publicado: publicado_por,
            token: token
        })
    })
    .then(response => response.json())
    .then(result => {
        let obt = result.resultado;

        if(obt){
            app.preloader.hide();
            app.dialog.alert(obt, function(){
                $$(".popup-close").click();
                cargarDatos();
            });
        }
    })
    .catch(error => {
        app.preloader.hide();
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            app.dialog.alert("Para Actualizar los Datos Revise su conexión a internet");
        }
    });
});